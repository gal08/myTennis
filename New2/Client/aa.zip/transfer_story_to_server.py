"""
Gal Haham
Media file uploader client - ENCRYPTED VERSION
Converts images/videos to Base64 and sends them to the media server via TCP
ENHANCED: Added full encryption support via Diffie-Hellman + AES
FIXED: Corrected payload sending to match server expectations
"""
import socket
import base64
import json
import struct
import os
from pathlib import Path
import key_exchange
import aes_cipher
from Protocol import Protocol


# Network Configuration
HOST = "127.0.0.1"
PORT = 3333
MSG_LEN = 1024

# Protocol
PAYLOAD_SIZE_BYTES = 4
PAYLOAD_SIZE_FORMAT = "!I"

# File Types
VIDEO_EXTENSION = ".mp4"
MEDIA_TYPE_VIDEO = "video"
MEDIA_TYPE_IMAGE = "image"

# File Mode
FILE_MODE_READ_BINARY = "rb"

# Default Values
DEFAULT_USERNAME = "user"

# Error Messages
ERROR_FILE_NOT_FOUND = "file not found"

SOCK_INDEX = 0
KEY_INDEX = 1


class MediaClient:
    """
    MediaClient sends image/video files to a remote server with ENCRYPTION.

    Responsibilities:
    - Load a media file (image or mp4).
    - Convert file to Base64 encoded string.
    - Build a JSON payload containing file + metadata.
    - ENCRYPT the payload with AES-256
    - Send encrypted payload to server
    - Read a short server response.
    """

    def __init__(self, host=HOST, port=PORT):
        """
        Initialize the media client.

        Args:
            host: Server hostname/IP address
            port: Server port number
        """
        self.host = host
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect((self.host, self.port))
        temp_conn = (self.socket, None)
        key = key_exchange.KeyExchange.send_recv_key(temp_conn)
        self.conn = (self.socket, key)

    def send_media(self, file_path, username=DEFAULT_USERNAME):
        """
        Send a media file (image or video) to the server with ENCRYPTION.

        Steps performed:
        1. Verifies that the file exists.
        2. Reads the file as raw bytes.
        3. Converts the file into Base64 so it can be sent as text.
        4. Detects whether the file is an image or a video based on extension.
        5. Builds a JSON payload
        6. Establishes encrypted connection
        7. Encrypts the payload with AES
        8. Sends the size of the encrypted payload and then the payload itself
        9. Waits for a short response from the server and prints it.

        Args:
            file_path: Path to media file (image or video)
            username: Username to associate with the upload

        Raises:
            FileNotFoundError: If file does not exist
        """
        # Load and encode file
        file_bytes = self._load_file(file_path)
        b64_data = self._encode_to_base64(file_bytes)

        # Detect media type and build payload
        media_type = self._detect_media_type(file_path)
        payload_json = self._build_payload(username, media_type, b64_data)

        # Send to server with encryption
        response = self._send_to_server_encrypted(payload_json)
        print(f"Server response: {response}")

    def _load_file(self, file_path):
        """
        Load file from disk and return bytes.

        Args:
            file_path: Path to file

        Returns:
            bytes: File contents

        Raises:
            FileNotFoundError: If file does not exist
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(ERROR_FILE_NOT_FOUND)

        with open(file_path, FILE_MODE_READ_BINARY) as f:
            return f.read()

    def _encode_to_base64(self, file_bytes):
        """
        Encode file bytes to Base64 string.

        Args:
            file_bytes: Raw file bytes

        Returns:
            str: Base64 encoded string
        """
        return base64.b64encode(file_bytes).decode()

    def _detect_media_type(self, file_path):
        """
        Detect media type based on file extension.

        Args:
            file_path: Path to media file

        Returns:
            str: "video" if .mp4, "image" otherwise
        """
        ext = Path(file_path).suffix.lower()
        return MEDIA_TYPE_VIDEO if ext == VIDEO_EXTENSION else MEDIA_TYPE_IMAGE

    def _build_payload(self, username, media_type, b64_data):
        """
        Build JSON payload with media data.

        Args:
            username: Username for upload
            media_type: Type of media ("image" or "video")
            b64_data: Base64 encoded media data

        Returns:
            str: JSON payload as string (not bytes!)
        """
        payload = {
            "username": username,
            "media_type": media_type,
            "data": b64_data
        }
        return json.dumps(payload)

    def _send_to_server_encrypted(self, payload_json):
        """
        Send ENCRYPTED payload to server and receive response.

        FIXED: Send the JSON payload directly,
         not wrapped in another JSON object.
        The Protocol.send() will handle the encryption automatically.

        Args:
            payload_json: JSON string to send

        Returns:
            str: Server response message
        """
        # Send the JSON payload directly - Protocol.send handles encryption
        Protocol.send(payload_json, self.conn)

        # Receive and return server response
        response_data = Protocol.recv(self.conn)
        return response_data


def run(file_path, username=DEFAULT_USERNAME):
    """
    Helper function to send a file in one line with ENCRYPTION.

    Args:
        file_path: Path to media file to upload
        username: Username to associate with upload
    """
    client = MediaClient()
    client.send_media(file_path, username)
