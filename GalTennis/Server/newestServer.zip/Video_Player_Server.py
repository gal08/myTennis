"""
Gal Haham
Video & audio streaming server - Main Entry Point
This is the main file that should be imported by Server.py
"""
from VideoAudioServer import run_video_player_server

# Export the main function
__all__ = ['run_video_player_server']
