"""
Gal Haham
Request Methods Handler - FIXED VERSION
Routes client requests to appropriate handlers.
ADDED: PLAY_VIDEO handler to start video streaming server
"""
import threading
import time
import os

from Authication import Authentication
from Videos_Handler import VideosHandler
from Likes_Handler import LikesHandler
from Comments_Handler import CommentsHandler
from Stories_Handler import StoriesHandler
from Manger_commands import ManagerCommands

class RequestMethodsHandler:
    """
    Routes client requests to appropriate handlers.
    Contains all business logic for request processing.
    """

    def __init__(self):
        """Initialize all request handlers."""
        # Import handlers


        self.auth = Authentication()
        self.videos = VideosHandler()
        self.stories = StoriesHandler()
        self.comments = CommentsHandler()
        self.likes = LikesHandler()

        # Track active video servers
        self.active_video_servers = {}
        self.video_servers_lock = threading.Lock()

    def route_request(self, request_data: dict) -> dict:
        """
        Route request to appropriate handler.

        Args:
            request_data: Dictionary with 'type' and 'payload'

        Returns:
            Response dictionary
        """
        request_type = request_data.get('type')
        payload = request_data.get('payload', {})

        print(f"[ROUTER] Routing request type: {request_type}")

        # Authentication routes
        if request_type in ['LOGIN', 'SIGNUP', 'LOGOUT']:
            return self.auth.handle_request(request_type, payload)

        # Video routes
        elif request_type in ['ADD_VIDEO', 'GET_VIDEOS']:
            return self.videos.handle_request(request_type, payload)

        # Story routes
        elif request_type in ['ADD_STORY', 'GET_STORIES']:
            return self.stories.handle_request(request_type, payload)

        # Comments routes
        elif request_type in ['ADD_COMMENT', 'GET_COMMENTS']:
            return self.comments.handle_request(request_type, payload)

        # Likes routes
        elif request_type in ['LIKE_VIDEO', 'GET_LIKES_COUNT']:
            return self.likes.handle_request(request_type, payload)

        # ✅ NEW: Video playback route
        elif request_type == 'PLAY_VIDEO':
            return self.handle_play_video(payload)

        else:
            return {
                "status": "error",
                "message": f"Unknown request type: {request_type}"
            }

    def handle_play_video(self, payload: dict) -> dict:
        """
        Start video streaming server for requested video.

        Args:
            payload: Dictionary with 'video_title'

        Returns:
            Response dictionary with status
        """
        video_title = payload.get('video_title')

        if not video_title:
            return {
                "status": "error",
                "message": "Missing video_title in request"
            }

        print(f"[PLAY_VIDEO] Starting video server for: {video_title}")

        # Find video file path
        video_path = self._find_video_path(video_title)

        if not video_path:
            return {
                "status": "error",
                "message": f"Video file not found: {video_title}"
            }

        print(f"[PLAY_VIDEO] Found video at: {video_path}")

        # Check if video server already running for this video
        with self.video_servers_lock:
            if video_title in self.active_video_servers:
                server_thread = self.active_video_servers[video_title]
                if server_thread.is_alive():
                    print(f"[PLAY_VIDEO] Video server already running")
                    return {
                        "status": "success",
                        "message": "Video server already running",
                        "port": 9999
                    }

        # Start video streaming server in background
        try:
            from Video_Player_Server import run_video_player_server

            def start_video_server():
                try:
                    print(f"[VIDEO SERVER] Starting for {video_title}...")
                    run_video_player_server(video_path)
                    print(f"[VIDEO SERVER] Finished for {video_title}")
                except Exception as e:
                    print(f"[VIDEO SERVER ERROR] {e}")
                    import traceback
                    traceback.print_exc()
                finally:
                    # Remove from active servers when done
                    with self.video_servers_lock:
                        if video_title in self.active_video_servers:
                            del self.active_video_servers[video_title]

            # Create and start thread
            video_thread = threading.Thread(
                target=start_video_server,
                daemon=True,
                name=f"VideoServer-{video_title}"
            )
            video_thread.start()

            # Track active server
            with self.video_servers_lock:
                self.active_video_servers[video_title] = video_thread

            # Wait for server to initialize
            print("[PLAY_VIDEO] Waiting for video server to initialize...")
            time.sleep(2.5)

            print("[PLAY_VIDEO] Video server started successfully")
            return {
                "status": "success",
                "message": "Video server started",
                "port": 9999
            }

        except ImportError as e:
            print(f"[PLAY_VIDEO ERROR] Import error: {e}")
            return {
                "status": "error",
                "message": f"Video server module not found: {e}"
            }
        except Exception as e:
            print(f"[PLAY_VIDEO ERROR] {e}")
            import traceback
            traceback.print_exc()
            return {
                "status": "error",
                "message": f"Failed to start video server: {e}"
            }

    def _find_video_path(self, video_title: str) -> str:
        """
        Find video file path by title.

        Args:
            video_title: Video title to search for

        Returns:
            Full path to video file or None if not found
        """
        # Common video extensions
        VIDEO_EXTENSIONS = ['.mp4', '.avi', '.mov', '.mkv', '.flv', '.wmv']
        VIDEO_FOLDER = "videos"

        # Ensure folder exists
        if not os.path.exists(VIDEO_FOLDER):
            print(f"[FIND VIDEO] Videos folder not found: {VIDEO_FOLDER}")
            return None

        # Try exact match with different extensions
        for ext in VIDEO_EXTENSIONS:
            # Try with extension
            video_path = os.path.join(VIDEO_FOLDER, f"{video_title}{ext}")
            if os.path.exists(video_path):
                print(f"[FIND VIDEO] Found: {video_path}")
                return video_path

            # Try title already has extension
            video_path = os.path.join(VIDEO_FOLDER, video_title)
            if os.path.exists(video_path):
                print(f"[FIND VIDEO] Found: {video_path}")
                return video_path

        # Search all files in folder
        try:
            for filename in os.listdir(VIDEO_FOLDER):
                # Check if filename matches (case-insensitive)
                if filename.lower().startswith(video_title.lower()):
                    video_path = os.path.join(VIDEO_FOLDER, filename)
                    if os.path.isfile(video_path):
                        print(f"[FIND VIDEO] Found (fuzzy): {video_path}")
                        return video_path
        except Exception as e:
            print(f"[FIND VIDEO ERROR] {e}")

        print(f"[FIND VIDEO] Not found: {video_title}")
        return None